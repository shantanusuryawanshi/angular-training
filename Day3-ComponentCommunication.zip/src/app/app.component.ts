import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Welcome to Hello World Component';
  sallary = "10 Lacs";
packages:any = [
  {name: "Free", price: "$0", users: "10", storage: "2gb", email: "10", isSignUp: true},
  {name: "Pro", price: "$0", users: "10", storage: "2gb", email: "10", isSignUp: false},
  {name: "Enterprice", price: "$0", users: "10", storage: "2gb", email: "10", isSignUp: false}
  ]

  employess:any = [{
    name: "Shantanu Suryawanshi",
    desc: "This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.",
    img: "https://via.placeholder.com/350x250",
    isPassOut: false
  },
  {
    name: "Ankit Choudhary",
    desc: "This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.",
    img: "https://via.placeholder.com/350x250",
    isPassOut: false
  },
  {
    name: "Aditya Mishra",
    desc: "This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.",
    img: "https://via.placeholder.com/350x250",
    isPassOut: true
  },
  {
    name: "Sagar Patil",
    desc: "This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.",
    img: "https://via.placeholder.com/350x250",
    isPassOut: true
  },
  {
    name: "Navtesh Hartalekar",
    desc: "This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.",
    img: "https://via.placeholder.com/350x250",
    isPassOut: true
  },
  {
    name: "Shruti Malkar",
    desc: "This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.",
    img: "https://via.placeholder.com/350x250",
    isPassOut: true
  }
  ];
  selectedData;

  getSelectedEmployeeData(data){
    this.selectedData = data;
  }
}
