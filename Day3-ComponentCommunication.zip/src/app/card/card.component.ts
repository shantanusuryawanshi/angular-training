import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent implements OnInit {
 @Input() employeeData:any;
 @Input() salary:any;
 @Output() selectedEmployee = new EventEmitter();
  constructor() { }

  sendData(param1){
    console.log("this",param1);
    this.selectedEmployee.emit(param1);
  }

  ngOnInit(): void {
    
  }

}
