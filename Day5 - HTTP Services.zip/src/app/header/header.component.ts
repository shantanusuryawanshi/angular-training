import { Component } from '@angular/core';
import { UtilityService } from '../services/utility.service'
@Component({
  selector: 'header-sagar',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})

export class HeaderComponent{
  carts = []; 
  colorsArr = [];
  constructor(public commonData:UtilityService) { }

  getData(){
    this.colorsArr = this.commonData.getColorsData('type');
    // this.colorsArr = this.commonData.getColorsData();
  }
}
