import { Component, OnInit } from '@angular/core';
import { AppService } from './../services/app.service';

@Component({
  selector: 'app-userlisting',
  templateUrl: './userlisting.component.html',
  styleUrls: ['./userlisting.component.scss']
})
export class UserlistingComponent implements OnInit {
  usersData: any;
  constructor(private AppService:AppService) { }

  ngOnInit(): void {
    this.AppService.getUsers().subscribe((data)=>{
      // console.log("getUsers",data);
      this.usersData = data;
    });
    
    this.AppService.getProducts().subscribe((data)=>{
      // console.log("getProducts",data);
    });
    // console.log("this.usersData",this.usersData)
  }

  

}
