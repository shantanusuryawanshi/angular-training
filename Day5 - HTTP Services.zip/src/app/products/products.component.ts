import { Component, OnInit } from '@angular/core';
import { AppService } from './../services/app.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent implements OnInit {
  productsData:any;
  constructor(private AppService: AppService) { }
  ngOnInit(): void {
    this.AppService.getProducts().subscribe((items)=>{
      // console.log("items",items);
      this.productsData = items;
    })
  }

}
