export const environment = {
  production: true,
  base_url: "http://locahost:4200/data/"
};
